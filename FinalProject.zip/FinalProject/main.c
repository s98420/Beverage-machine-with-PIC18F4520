#include "setting_hardaware/setting.h"
#include <stdlib.h>
#include "stdio.h"
#include "string.h"
#include <xc.h>
#include <time.h>
#define _XTAL_FREQ 1000000
#define ContinueMode 1
#define NormalMode 0

int Mode = NormalMode;
int whichOutput = 4;
void changeModeInterrupt();
void NormalOut();
void ContinueOut();
void timerInterrupt();
int interruptCount = 0;

void __interrupt(high_priority)H_ISR(){
    if(INTCON3bits.INT1IF){
        changeModeInterrupt();
    }
    if(PIR1bits.TMR2IF){
        timerInterrupt();
    }
    
    
    return;
}

char welcome[9] = "welcome!";
char now[4] = "now";
char its[6] = "it's ";
char delete[6] = "-----";

char changing[10] = "changing ";
char to[4] = "to ";
char normal[7] = "normal";
char continous[10] = "continous";
char mode[7] = " mode ";
char mm[3] = " ";
char out[10] = "outputing";
char cola[6] = " cola";
char sprite[8] = " sprite";
char fanta[7] = " fanta";
char are[5] = "are ";
char U[5] = "you ";
char ser[9] = "serious?";
char start[7] = "start ";
char stop[6] = "stop ";


void main(void) 
{
    SYSTEM_Initialize();
    TRISAbits.RA0 = 0; //RA = motors
    TRISAbits.RA1 = 0;
    TRISAbits.RA2 = 0;
    
    //TRISDbits.RD3 = 0; //
    //TRISDbits.RD2 = 0;
    
    TRISCbits.RC7 = 0;
    TRISCbits.RC6 = 1;
    TRISCbits.RC4 = 0;
    
    
    LATAbits.LATA0 = 0;
    LATAbits.LATA1 = 0;
    LATAbits.LATA2 = 0;
    
    //LATDbits.LATD3 = 0;
    //LATDbits.LATD2 = 0;
    
    //LATCbits.LATC4 = 0;
    
    TRISBbits.RB1 = 1; //RB1 = chooose mode input
    TRISBbits.RB5 = 1;
    TRISBbits.RB4 = 1;
    TRISBbits.RB3 = 1;
    
    ADCON1 = 15;       //set digital 00001111
    
    //set interrupt 1
    INTCON3bits.INT1IP = 1;
    INTCON3bits.INT1IE = 1;
    INTCON3bits.INT1IF = 0;
    
    RCONbits.IPEN = 1;  //Enable priority levels on interrupts
    
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    
    PIR1bits.TMR2IF = 0;
    IPR1bits.TMR2IP = 1;
    PIE1bits.TMR2IE = 1;
    T2CON = 255;
    T2CONbits.TMR2ON = 0;
    PR2 = 255;
    
    UART_Write_Text(welcome);
    UART_Write('\r');
    UART_Write('\n');
    while(1){
        if(Mode == NormalMode){
            NormalOut();
        }
        else if(Mode == ContinueMode){
            ContinueOut();
        }
    }
    
    return;
}
void changeModeInterrupt(){
    
    if(Mode == NormalMode){
        Mode = ContinueMode;
        UART_Write_Text(changing);
        UART_Write_Text(to);
        UART_Write_Text(continous);
        UART_Write_Text(mode);
        UART_Write_Text(mm);
        UART_Write('\r');
        UART_Write('\n');
        UART_Write_Text(delete);
        UART_Write_Text(its);
        UART_Write_Text(continous);
        UART_Write_Text(mode);
        UART_Write_Text(now);
        UART_Write_Text(delete);
        UART_Write('\r');
        UART_Write('\n');
        UART_Write('\r');
        UART_Write('\n');        
    }
    else if(Mode == ContinueMode){
        Mode = NormalMode;
        UART_Write_Text(changing);
        UART_Write_Text(to);
        UART_Write_Text(normal);
        UART_Write_Text(mode);
        UART_Write_Text(mm);
        UART_Write('\r');
        UART_Write('\n');
        UART_Write_Text(delete);
        UART_Write_Text(its);
        UART_Write_Text(normal);
        UART_Write_Text(mode);
        UART_Write_Text(now);
        UART_Write_Text(delete);
        UART_Write('\r');
        UART_Write('\n');
        UART_Write('\r');
        UART_Write('\n');
    }
    INTCON3bits.INT1IF = 0;
    __delay_ms(1000);
    return;
}

void ContinueOut(){
    if(PORTBbits.RB3 == 0 && (whichOutput == 4 || whichOutput == 0)){
        LATAbits.LATA0 = !LATAbits.LATA0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 0;
        PIR1bits.TMR2IF = 0;
        CCPR2H = 0;
        CCPR2L = 0;
        if(whichOutput == 4){
            UART_Write_Text(delete);
            UART_Write_Text(start);
            UART_Write_Text(out);
            UART_Write_Text(cola);
            UART_Write_Text(delete);
            whichOutput = 0;
            UART_Write('\r');
            UART_Write('\n'); 
            T2CONbits.TMR2ON = 1;
        }
        else if(whichOutput == 0){
            UART_Write_Text(delete);
            UART_Write_Text(stop);
            UART_Write_Text(out);
            UART_Write_Text(cola);
            UART_Write_Text(delete);
            UART_Write('\r');
            UART_Write('\n'); 
            whichOutput = 4;
            //LATDbits.LATD2 = 0;
            //LATDbits.LATD3 = 0;
            T2CONbits.TMR2ON = 0;
                    
        }
        CCPR2H = 0;
        CCPR2L = 0;
        __delay_ms(1000);
    }
    else if(PORTBbits.RB4 == 0 && (whichOutput == 4 || whichOutput == 1)){
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = !LATAbits.LATA1;
        LATAbits.LATA2 = 0;
        PIR1bits.TMR2IF = 0;
        CCPR2H = 0;
        CCPR2L = 0;
        if(whichOutput == 4){
            UART_Write_Text(delete);
            UART_Write_Text(start);
            UART_Write_Text(out);
            UART_Write_Text(sprite);
            UART_Write_Text(delete);            
            whichOutput = 1;
            UART_Write('\r');
            UART_Write('\n');            
            T2CONbits.TMR2ON = 1;
        }
        else if(whichOutput == 1){
            UART_Write_Text(delete);
            UART_Write_Text(stop);
            UART_Write_Text(out);
            UART_Write_Text(sprite);
            UART_Write_Text(delete);
            UART_Write('\r');
            UART_Write('\n'); 
            whichOutput = 4;
            //LATDbits.LATD2 = 0;
            //LATDbits.LATD3 = 0;
            T2CONbits.TMR2ON = 0;
        }
        __delay_ms(1000);
    }
    else if(PORTBbits.RB5 == 0 && (whichOutput == 4 || whichOutput == 2)){
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = !LATAbits.LATA2;
        PIR1bits.TMR2IF = 0;
        CCPR2H = 0;
        CCPR2L = 0;
        if(whichOutput == 4){
            UART_Write_Text(delete);
            UART_Write_Text(start);
            UART_Write_Text(out);
            UART_Write_Text(fanta);
            UART_Write_Text(delete);
            UART_Write('\r');
            UART_Write('\n');
            whichOutput = 2;
            T2CONbits.TMR2ON = 1;
        }
        else if(whichOutput == 2){
            whichOutput = 4;
            //LATDbits.LATD2 = 0;
            //LATDbits.LATD3 = 0;
            UART_Write_Text(delete);
            UART_Write_Text(stop);            
            UART_Write_Text(out);
            UART_Write_Text(fanta);
            UART_Write_Text(delete);
            UART_Write('\r');
            UART_Write('\n'); 
            T2CONbits.TMR2ON = 0;
        }
        __delay_ms(1000);
    }
    else if((PORTBbits.RB3 == 0 && (whichOutput == 1 || whichOutput == 2))|| (PORTBbits.RB4 == 0 && (whichOutput == 0 || whichOutput == 2)) || (PORTBbits.RB5 == 0 && (whichOutput == 1 || whichOutput == 0))){
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 0;
        PIR1bits.TMR2IF = 0;
        T2CONbits.TMR2ON = 0;
        whichOutput = 4;
        //LATDbits.LATD3 = 0;
        //LATDbits.LATD2 = 0;
        CCPR2H = 0;
        CCPR2L = 0;
        UART_Write_Text(are);
        UART_Write_Text(U);
        UART_Write_Text(ser);
        UART_Write('\r');
        UART_Write('\n');        
        __delay_ms(1000);
        //dont play water ^_^
    }
    return;
}


void NormalOut(){
    
    if(PORTBbits.RB3 == 0){
        LATAbits.LATA0 = 1;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 0;
    }
    else if(PORTBbits.RB4 == 0){
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 1;
        LATAbits.LATA2 = 0;
    }
    else if(PORTBbits.RB5 == 0){
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 1;
    }
    else{
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 0;
    }
}
void timerInterrupt(){
    /*if(whichOutput == 0){
        LATDbits.LATD2 = !LATDbits.LATD2;
    }
    else if(whichOutput == 1){
        LATDbits.LATD3 = !LATDbits.LATD3;
    }
    else if(whichOutput == 2){
        LATCbits.LATC4 = !LATCbits.LATC4;
    }*/
    if(interruptCount < 10){
        interruptCount++;
    }
    else{
        interruptCount = 0;
        LATAbits.LATA0 = 0;
        LATAbits.LATA1 = 0;
        LATAbits.LATA2 = 0;
        whichOutput = 4;
        UART_Write_Text(delete);
        UART_Write_Text(stop);
        UART_Write_Text(out);
        UART_Write_Text(delete);
        UART_Write('\r');
        UART_Write('\n');
        T2CONbits.TMR2ON = 0;
        
    }
    PIR1bits.TMR2IF = 0;
}